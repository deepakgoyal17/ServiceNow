import React from 'react';
import LineChart from '../charts/LineChart';
import SummaryCard from '../ui/SummaryCard';
import type { DailyStats } from '../../types';
import { format, parseISO } from 'date-fns';

interface TrendChartProps {
  data: DailyStats[];
  className?: string;
}

const TrendChart: React.FC<TrendChartProps> = ({ data, className = '' }) => {
  // Format dates for display
  const labels = data.map((item) => format(parseISO(item.date), 'MMM dd'));
  
  // Extract data points
  const ticketsData = data.map((item) => item.ticketsResolved);
  const ritmsData = data.map((item) => item.ritmsFulfilled);

  return (
    <SummaryCard title="Resolution Trends" className={`${className}`}>
      <div className="h-[300px]">
        <LineChart 
          labels={labels}
          datasets={[
            {
              label: 'Tickets Resolved',
              data: ticketsData,
              borderColor: '#0066CC',
              backgroundColor: 'rgba(0, 102, 204, 0.1)',
            },
            {
              label: 'RITMs Fulfilled',
              data: ritmsData,
              borderColor: '#FF9500',
              backgroundColor: 'rgba(255, 149, 0, 0.1)',
            },
          ]}
        />
      </div>
    </SummaryCard>
  );
};

export default TrendChart;
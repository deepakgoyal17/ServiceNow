import React from 'react';
import DoughnutChart from '../charts/DoughnutChart';
import SummaryCard from '../ui/SummaryCard';
import type { CategoryDistribution } from '../../types';

interface CategoryDistributionCardProps {
  title: string;
  data: CategoryDistribution[];
  className?: string;
  chartColors?: string[];
}

const CategoryDistributionCard: React.FC<CategoryDistributionCardProps> = ({ 
  title, 
  data, 
  className = '',
  chartColors = [
    '#0066CC', '#FF9500', '#34C759', '#FFCC00', '#5856D6', '#AF52DE', '#FF2D55', '#007AFF'
  ]
}) => {
  // Filter categories with count > 0 and sort by count descending
  const filteredData = [...data]
    .filter(item => item.count > 0)
    .sort((a, b) => b.count - a.count);
  
  // Extract data for chart
  const labels = filteredData.map(item => item.category);
  const counts = filteredData.map(item => item.count);
  
  // Ensure we have enough colors
  const colors = chartColors.length >= filteredData.length
    ? chartColors.slice(0, filteredData.length)
    : [...chartColors, ...Array(filteredData.length - chartColors.length).fill('#6B7280')];

  return (
    <SummaryCard title={title} className={`${className}`}>
      <div className="h-[300px]">
        <DoughnutChart 
          labels={labels}
          datasets={[
            {
              data: counts,
              backgroundColor: colors,
              borderWidth: 1,
              borderColor: colors.map(color => color.replace(')', ', 0.1)').replace('rgb', 'rgba')),
            },
          ]}
          height={300}
        />
      </div>
    </SummaryCard>
  );
};

export default CategoryDistributionCard;
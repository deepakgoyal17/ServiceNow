import React from 'react';
import { User, Check, Clock } from 'lucide-react';
import SummaryCard from '../ui/SummaryCard';
import type { TeamMetrics } from '../../types';

interface TeamPerformanceCardProps {
  data: TeamMetrics[];
  className?: string;
}

const TeamPerformanceCard: React.FC<TeamPerformanceCardProps> = ({ data, className = '' }) => {
  // Sort by total resolved (tickets + RITMs) descending
  const sortedData = [...data].sort(
    (a, b) => (b.ticketsResolved + b.ritmsFulfilled) - (a.ticketsResolved + a.ritmsFulfilled)
  );

  return (
    <SummaryCard title="Team Performance" className={className}>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-neutral-200">
          <thead className="bg-neutral-50">
            <tr>
              <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Team Member
              </th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Tickets
              </th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                RITMs
              </th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                SLA/SLX
              </th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Avg Time
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-neutral-200">
            {sortedData.map((member) => (
              <tr key={member.memberId} className="hover:bg-neutral-50">
                <td className="px-4 py-3 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-9 w-9 bg-primary-100 rounded-full flex items-center justify-center">
                      <User size={18} className="text-primary-600" />
                    </div>
                    <div className="ml-3">
                      <div className="text-sm font-medium text-neutral-900">{member.name}</div>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 whitespace-nowrap">
                  <div className="text-sm text-neutral-900">{member.ticketsResolved}</div>
                </td>
                <td className="px-4 py-3 whitespace-nowrap">
                  <div className="text-sm text-neutral-900">{member.ritmsFulfilled}</div>
                </td>
                <td className="px-4 py-3 whitespace-nowrap">
                  <div className="flex items-center">
                    <Check size={16} className="text-success-500 mr-1" />
                    <span className="text-sm text-neutral-900">
                      {member.slaCompliance}% / {member.slxCompliance}%
                    </span>
                  </div>
                </td>
                <td className="px-4 py-3 whitespace-nowrap">
                  <div className="flex items-center">
                    <Clock size={16} className="text-primary-500 mr-1" />
                    <span className="text-sm text-neutral-900">{member.avgResolutionTime} days</span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </SummaryCard>
  );
};

export default TeamPerformanceCard;
import React from 'react';
import { ClipboardList, Clock, AlertCircle } from 'lucide-react';
import MetricCard from '../ui/MetricCard';
import SummaryCard from '../ui/SummaryCard';
import type { RITMMetrics } from '../../types';

interface RITMMetricsCardProps {
  metrics: RITMMetrics;
  className?: string;
}

const RITMMetricsCard: React.FC<RITMMetricsCardProps> = ({ metrics, className = '' }) => {
  return (
    <SummaryCard title="RITM Metrics" className={className}>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <MetricCard 
          title="RITMs Fulfilled"
          value={`${metrics.fulfilled}/${metrics.total}`}
          description={`${metrics.fulfillmentRate}% fulfillment rate`}
          trend={{ value: 10, positive: true }}
          icon={<ClipboardList size={20} />}
        />
        
        <MetricCard 
          title="Avg Fulfillment Time"
          value={metrics.avgFulfillmentTime}
          description="days to fulfillment"
          trend={{ value: 5, positive: true }}
          icon={<Clock size={20} />}
          formatter={(value) => `${value} days`}
        />
        
        <MetricCard 
          title="SLX Compliance"
          value={metrics.slxCompliance}
          description="RITMs fulfilled within SLX"
          trend={{ value: 3, positive: true }}
          icon={<AlertCircle size={20} />}
          isPercentage
        />
      </div>
    </SummaryCard>
  );
};

export default RITMMetricsCard;
import React from 'react';
import { Ticket, Clock, AlertCircle } from 'lucide-react';
import MetricCard from '../ui/MetricCard';
import SummaryCard from '../ui/SummaryCard';
import type { TicketMetrics } from '../../types';

interface TicketMetricsCardProps {
  metrics: TicketMetrics;
  className?: string;
}

const TicketMetricsCard: React.FC<TicketMetricsCardProps> = ({ metrics, className = '' }) => {
  return (
    <SummaryCard title="Ticket Metrics" className={className}>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <MetricCard 
          title="Tickets Resolved"
          value={`${metrics.resolved}/${metrics.total}`}
          description={`${metrics.resolutionRate}% resolution rate`}
          trend={{ value: 12, positive: true }}
          icon={<Ticket size={20} />}
        />
        
        <MetricCard 
          title="Avg Resolution Time"
          value={metrics.avgResolutionTime}
          description="days to resolution"
          trend={{ value: 8, positive: true }}
          icon={<Clock size={20} />}
          formatter={(value) => `${value} days`}
        />
        
        <MetricCard 
          title="SLA Compliance"
          value={metrics.slaCompliance}
          description="tickets resolved within SLA"
          trend={{ value: 5, positive: true }}
          icon={<AlertCircle size={20} />}
          isPercentage
        />
      </div>
    </SummaryCard>
  );
};

export default TicketMetricsCard;
import React from 'react';
import { CalendarClock } from 'lucide-react';
import type { TimeFilter as TimeFilterType } from '../../types';

interface TimeFilterProps {
  value: TimeFilterType;
  onChange: (value: TimeFilterType) => void;
}

const TimeFilter: React.FC<TimeFilterProps> = ({ value, onChange }) => {
  return (
    <div className="flex items-center space-x-2 bg-white border border-neutral-200 rounded-lg p-1 shadow-sm">
      <CalendarClock size={18} className="ml-2 text-neutral-500" />
      <div className="flex">
        <button
          className={`px-3 py-1.5 text-sm font-medium rounded-md ${
            value === 'week'
              ? 'bg-primary-500 text-white'
              : 'text-neutral-600 hover:bg-neutral-100'
          }`}
          onClick={() => onChange('week')}
        >
          Week
        </button>
        <button
          className={`px-3 py-1.5 text-sm font-medium rounded-md ${
            value === 'month'
              ? 'bg-primary-500 text-white'
              : 'text-neutral-600 hover:bg-neutral-100'
          }`}
          onClick={() => onChange('month')}
        >
          Month
        </button>
        <button
          className={`px-3 py-1.5 text-sm font-medium rounded-md ${
            value === 'quarter'
              ? 'bg-primary-500 text-white'
              : 'text-neutral-600 hover:bg-neutral-100'
          }`}
          onClick={() => onChange('quarter')}
        >
          Quarter
        </button>
      </div>
    </div>
  );
};

export default TimeFilter;
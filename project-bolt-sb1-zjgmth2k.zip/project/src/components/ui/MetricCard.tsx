import React from 'react';
import { ArrowDown, ArrowUp, TrendingUp } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: number | string;
  description?: string;
  trend?: {
    value: number;
    positive: boolean;
  };
  icon?: React.ReactNode;
  formatter?: (value: number | string) => string;
  className?: string;
  isPercentage?: boolean;
}

const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  description,
  trend,
  icon,
  formatter,
  className = '',
  isPercentage = false,
}) => {
  const formattedValue = formatter ? formatter(value) : isPercentage ? `${value}%` : value;
  
  return (
    <div className={`card hover:scale-[1.01] transition-all duration-300 ${className}`}>
      <div className="flex items-start justify-between">
        <div>
          <h3 className="text-neutral-600 font-medium text-sm">{title}</h3>
          <p className="text-2xl font-semibold mt-1 mb-1">{formattedValue}</p>
          {description && <p className="text-sm text-neutral-500">{description}</p>}
        </div>
        <div className="p-2 rounded-lg bg-primary-50 text-primary-500">
          {icon || <TrendingUp size={20} />}
        </div>
      </div>
      
      {trend && (
        <div className="mt-2 flex items-center">
          <div className={`flex items-center mr-2 ${trend.positive ? 'text-success-600' : 'text-error-600'}`}>
            {trend.positive ? <ArrowUp size={16} /> : <ArrowDown size={16} />}
            <span className="text-sm font-medium ml-1">{trend.value}%</span>
          </div>
          <span className="text-xs text-neutral-500">vs last period</span>
        </div>
      )}
    </div>
  );
};

export default MetricCard;
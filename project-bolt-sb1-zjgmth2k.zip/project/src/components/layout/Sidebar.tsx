import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Ticket, 
  ClipboardList, 
  Users, 
  Settings, 
  LogOut,
  Menu,
  X
} from 'lucide-react';

type NavItem = {
  label: string;
  path: string;
  icon: React.ReactNode;
};

const navItems: NavItem[] = [
  { label: 'Dashboard', path: '/', icon: <LayoutDashboard size={20} /> },
  { label: 'Tickets', path: '/tickets', icon: <Ticket size={20} /> },
  { label: 'RITMs', path: '/ritms', icon: <ClipboardList size={20} /> },
  { label: 'Team', path: '/team', icon: <Users size={20} /> },
  { label: 'Settings', path: '/settings', icon: <Settings size={20} /> },
];

const Sidebar: React.FC = () => {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <>
      {/* Mobile menu toggle */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-50 bg-white px-4 py-2 shadow-sm flex justify-between items-center">
        <div className="flex items-center">
          <img src="/vite.svg" alt="Logo" className="h-8 w-8 mr-2" />
          <h1 className="text-lg font-semibold text-primary-600">ServiceNow Dashboard</h1>
        </div>
        <button 
          onClick={toggleMobileMenu}
          className="p-2 rounded-md text-neutral-500 hover:bg-neutral-100"
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
      
      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-40 bg-white pt-16 animate-fade-in">
          <nav className="flex flex-col p-4">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 mb-1 rounded-lg ${
                  location.pathname === item.path
                    ? 'bg-primary-500 text-white'
                    : 'text-neutral-700 hover:bg-neutral-100'
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {item.icon}
                <span>{item.label}</span>
              </Link>
            ))}
            <div className="mt-auto pt-4 border-t border-neutral-200">
              <button className="flex w-full items-center gap-3 px-4 py-3 text-neutral-700 hover:bg-neutral-100 rounded-lg">
                <LogOut size={20} />
                <span>Log Out</span>
              </button>
            </div>
          </nav>
        </div>
      )}
      
      {/* Desktop sidebar */}
      <aside className="hidden md:flex md:flex-col md:w-64 bg-white border-r border-neutral-200 h-screen sticky top-0">
        <div className="p-4 border-b border-neutral-200">
          <div className="flex items-center">
            <img src="/vite.svg" alt="Logo" className="h-8 w-8 mr-2" />
            <h1 className="text-lg font-semibold text-primary-600">ServiceNow Dashboard</h1>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto p-4">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-4 py-3 mb-1 rounded-lg ${
                location.pathname === item.path
                  ? 'bg-primary-500 text-white'
                  : 'text-neutral-700 hover:bg-neutral-100'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>
        <div className="p-4 border-t border-neutral-200">
          <button className="flex w-full items-center gap-3 px-4 py-3 text-neutral-700 hover:bg-neutral-100 rounded-lg">
            <LogOut size={20} />
            <span>Log Out</span>
          </button>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
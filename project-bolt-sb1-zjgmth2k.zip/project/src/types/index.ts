export type TimeFilter = 'week' | 'month' | 'quarter';

export interface TeamMember {
  id: string;
  name: string;
  avatar: string;
  role: string;
  department: string;
}

export interface Ticket {
  id: string;
  number: string;
  title: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  status: 'open' | 'in progress' | 'resolved' | 'closed';
  category: string;
  assignedTo: string;
  createdAt: string;
  resolvedAt: string | null;
  sla: {
    target: string;
    met: boolean;
  };
}

export interface RITM {
  id: string;
  number: string;
  title: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  status: 'open' | 'in progress' | 'fulfilled' | 'closed';
  category: string;
  assignedTo: string;
  createdAt: string;
  fulfilledAt: string | null;
  slx: {
    target: string;
    met: boolean;
  };
}

export interface TicketMetrics {
  total: number;
  resolved: number;
  resolutionRate: number;
  avgResolutionTime: number;
  slaCompliance: number;
}

export interface RITMMetrics {
  total: number;
  fulfilled: number;
  fulfillmentRate: number;
  avgFulfillmentTime: number;
  slxCompliance: number;
}

export interface TeamMetrics {
  memberId: string;
  name: string;
  ticketsResolved: number;
  ritmsFulfilled: number;
  slaCompliance: number;
  slxCompliance: number;
  avgResolutionTime: number;
}

export interface DailyStats {
  date: string;
  ticketsResolved: number;
  ritmsFulfilled: number;
}

export interface CategoryDistribution {
  category: string;
  count: number;
  percentage: number;
}
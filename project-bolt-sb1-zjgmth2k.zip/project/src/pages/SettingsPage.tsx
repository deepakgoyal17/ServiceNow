import React from 'react';
import { Bell, Clock, Shield, User, Zap, RefreshCw, Save } from 'lucide-react';
import SummaryCard from '../components/ui/SummaryCard';

const SettingsPage: React.FC = () => {
  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-neutral-900">Settings</h1>
        <p className="text-neutral-600 mt-1">Configure your dashboard preferences</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <SummaryCard title="Dashboard Settings" className="animate-slide-up">
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-medium text-neutral-700 mb-2">Data Refresh Interval</h3>
                <div className="flex flex-wrap gap-3">
                  <label className="flex items-center">
                    <input type="radio" name="refresh" className="h-4 w-4 text-primary-500 focus:ring-primary-500 border-neutral-300 rounded" defaultChecked />
                    <span className="ml-2 text-sm text-neutral-600">15 minutes</span>
                  </label>
                  <label className="flex items-center">
                    <input type="radio" name="refresh" className="h-4 w-4 text-primary-500 focus:ring-primary-500 border-neutral-300 rounded" />
                    <span className="ml-2 text-sm text-neutral-600">30 minutes</span>
                  </label>
                  <label className="flex items-center">
                    <input type="radio" name="refresh" className="h-4 w-4 text-primary-500 focus:ring-primary-500 border-neutral-300 rounded" />
                    <span className="ml-2 text-sm text-neutral-600">1 hour</span>
                  </label>
                  <label className="flex items-center">
                    <input type="radio" name="refresh" className="h-4 w-4 text-primary-500 focus:ring-primary-500 border-neutral-300 rounded" />
                    <span className="ml-2 text-sm text-neutral-600">Manual only</span>
                  </label>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium text-neutral-700 mb-2">Default Time Period</h3>
                <div className="flex flex-wrap gap-3">
                  <label className="flex items-center">
                    <input type="radio" name="time-period" className="h-4 w-4 text-primary-500 focus:ring-primary-500 border-neutral-300 rounded" />
                    <span className="ml-2 text-sm text-neutral-600">Week</span>
                  </label>
                  <label className="flex items-center">
                    <input type="radio" name="time-period" className="h-4 w-4 text-primary-500 focus:ring-primary-500 border-neutral-300 rounded" defaultChecked />
                    <span className="ml-2 text-sm text-neutral-600">Month</span>
                  </label>
                  <label className="flex items-center">
                    <input type="radio" name="time-period" className="h-4 w-4 text-primary-500 focus:ring-primary-500 border-neutral-300 rounded" />
                    <span className="ml-2 text-sm text-neutral-600">Quarter</span>
                  </label>
                </div>
              </div>
            </div>
          </SummaryCard>

          <SummaryCard title="ServiceNow Integration" className="animate-slide-up">
            <div className="space-y-4">
              <div>
                <label htmlFor="instance-url" className="block text-sm font-medium text-neutral-700 mb-1">
                  Instance URL
                </label>
                <input
                  type="text"
                  id="instance-url"
                  className="w-full px-3 py-2 border border-neutral-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                  placeholder="https://yourinstance.service-now.com"
                  defaultValue="https://example.service-now.com"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="api-username" className="block text-sm font-medium text-neutral-700 mb-1">
                    API Username
                  </label>
                  <input
                    type="text"
                    id="api-username"
                    className="w-full px-3 py-2 border border-neutral-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                    placeholder="Username"
                    defaultValue="api_user"
                  />
                </div>
                <div>
                  <label htmlFor="api-password" className="block text-sm font-medium text-neutral-700 mb-1">
                    API Password
                  </label>
                  <input
                    type="password"
                    id="api-password"
                    className="w-full px-3 py-2 border border-neutral-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                    placeholder="Password"
                    defaultValue="••••••••••••"
                  />
                </div>
              </div>

              <div className="pt-4">
                <button className="btn btn-primary">
                  <RefreshCw size={18} />
                  Test Connection
                </button>
              </div>
            </div>
          </SummaryCard>
        </div>

        <div className="lg:col-span-1 space-y-6">
          <SummaryCard title="Notification Settings" className="animate-slide-up">
            <div className="space-y-4">
              <label className="flex items-start">
                <div className="flex items-center h-5">
                  <input
                    type="checkbox"
                    className="h-4 w-4 text-primary-500 focus:ring-primary-500 border-neutral-300 rounded"
                    defaultChecked
                  />
                </div>
                <div className="ml-3 text-sm">
                  <span className="font-medium text-neutral-700">SLA Breach Alerts</span>
                  <p className="text-neutral-500">Notify when SLA or SLX targets are at risk</p>
                </div>
              </label>
              <label className="flex items-start">
                <div className="flex items-center h-5">
                  <input
                    type="checkbox"
                    className="h-4 w-4 text-primary-500 focus:ring-primary-500 border-neutral-300 rounded"
                    defaultChecked
                  />
                </div>
                <div className="ml-3 text-sm">
                  <span className="font-medium text-neutral-700">Daily Digest</span>
                  <p className="text-neutral-500">Receive daily summary of team performance</p>
                </div>
              </label>
              <label className="flex items-start">
                <div className="flex items-center h-5">
                  <input
                    type="checkbox"
                    className="h-4 w-4 text-primary-500 focus:ring-primary-500 border-neutral-300 rounded"
                  />
                </div>
                <div className="ml-3 text-sm">
                  <span className="font-medium text-neutral-700">New Tickets</span>
                  <p className="text-neutral-500">Notify when new tickets are assigned to your team</p>
                </div>
              </label>
            </div>
          </SummaryCard>
          
          <SummaryCard title="Account Settings" className="animate-slide-up">
            <div className="flex items-center mb-4">
              <div className="flex-shrink-0 h-12 w-12 bg-primary-100 rounded-full flex items-center justify-center">
                <User size={24} className="text-primary-600" />
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-medium">Manager Account</h3>
                <p className="text-sm text-neutral-500">IT Support Team</p>
              </div>
            </div>
            <div className="space-y-4">
              <button className="btn w-full flex justify-center items-center">
                <User size={18} className="mr-2" />
                Edit Profile
              </button>
              <button className="btn w-full flex justify-center items-center bg-neutral-100 hover:bg-neutral-200 text-neutral-700">
                <Shield size={18} className="mr-2" />
                Security Settings
              </button>
            </div>
          </SummaryCard>
        </div>
      </div>

      <div className="mt-6 flex justify-end">
        <button className="btn btn-accent">
          <Save size={18} className="mr-2" />
          Save Settings
        </button>
      </div>
    </div>
  );
};

export default SettingsPage;
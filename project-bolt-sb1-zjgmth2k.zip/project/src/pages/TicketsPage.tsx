import React, { useState, useEffect } from 'react';
import { AlertCircle, Clock, Filter, Search } from 'lucide-react';
import TimeFilter from '../components/ui/TimeFilter';
import { tickets } from '../constants/mockData';
import type { Ticket, TimeFilter as TimeFilterType } from '../types';

const TicketsPage: React.FC = () => {
  const [timeFilter, setTimeFilter] = useState<TimeFilterType>('month');
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredTickets, setFilteredTickets] = useState<Ticket[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate API fetch delay
    setIsLoading(true);
    const timer = setTimeout(() => {
      const filtered = tickets.filter(ticket => {
        const matchesSearch = searchQuery === '' ||
          ticket.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          ticket.number.toLowerCase().includes(searchQuery.toLowerCase());
        
        return matchesSearch;
      });
      
      setFilteredTickets(filtered);
      setIsLoading(false);
    }, 500);
    
    return () => clearTimeout(timer);
  }, [timeFilter, searchQuery]);

  const getPriorityClass = (priority: string) => {
    switch (priority) {
      case 'critical':
        return 'bg-error-100 text-error-700';
      case 'high':
        return 'bg-warning-100 text-warning-700';
      case 'medium':
        return 'bg-primary-100 text-primary-700';
      default:
        return 'bg-neutral-100 text-neutral-700';
    }
  };

  const getStatusClass = (status: string) => {
    switch (status) {
      case 'resolved':
      case 'closed':
        return 'bg-success-100 text-success-700';
      case 'in progress':
        return 'bg-primary-100 text-primary-700';
      default:
        return 'bg-neutral-100 text-neutral-700';
    }
  };

  return (
    <div className="animate-fade-in">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">Tickets</h1>
          <p className="text-neutral-600 mt-1">View and manage ServiceNow tickets</p>
        </div>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto">
          <div className="relative w-full sm:w-64">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-neutral-400" />
            </div>
            <input
              type="text"
              placeholder="Search tickets..."
              className="pl-10 pr-4 py-2 w-full border border-neutral-200 rounded-lg focus:ring-2 focus:ring-primary-200 focus:border-primary-500 outline-none"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <TimeFilter value={timeFilter} onChange={setTimeFilter} />
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-neutral-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-neutral-200">
            <thead className="bg-neutral-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Ticket
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Priority
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Category
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  SLA Status
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-neutral-200">
              {isLoading ? (
                <tr>
                  <td colSpan={5} className="px-6 py-4 text-center text-neutral-500">
                    Loading tickets...
                  </td>
                </tr>
              ) : filteredTickets.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-4 text-center text-neutral-500">
                    No tickets found.
                  </td>
                </tr>
              ) : (
                filteredTickets.map((ticket) => (
                  <tr key={ticket.id} className="hover:bg-neutral-50 cursor-pointer">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-start">
                        <div className="ml-0">
                          <div className="text-sm font-medium text-neutral-900">{ticket.title}</div>
                          <div className="text-sm text-neutral-500">{ticket.number}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${getPriorityClass(ticket.priority)}`}>
                        {ticket.priority.charAt(0).toUpperCase() + ticket.priority.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${getStatusClass(ticket.status)}`}>
                        {ticket.status.charAt(0).toUpperCase() + ticket.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-900">
                      {ticket.category}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        {ticket.sla.met ? (
                          <div className="flex items-center text-success-600">
                            <Clock size={16} className="mr-1" />
                            <span className="text-sm">Met SLA</span>
                          </div>
                        ) : (
                          <div className="flex items-center text-error-600">
                            <AlertCircle size={16} className="mr-1" />
                            <span className="text-sm">At Risk</span>
                          </div>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TicketsPage;
import React, { useState, useEffect } from 'react';
import { User, Award, Clock, Check, AlertCircle, Search } from 'lucide-react';
import TimeFilter from '../components/ui/TimeFilter';
import BarChart from '../components/charts/BarChart';
import SummaryCard from '../components/ui/SummaryCard';
import { teamMembers, teamPerformance } from '../constants/mockData';
import type { TeamMetrics, TimeFilter as TimeFilterType } from '../types';

const TeamPage: React.FC = () => {
  const [timeFilter, setTimeFilter] = useState<TimeFilterType>('month');
  const [searchQuery, setSearchQuery] = useState('');
  const [teamData, setTeamData] = useState<TeamMetrics[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate API fetch delay
    setIsLoading(true);
    const timer = setTimeout(() => {
      const filtered = teamPerformance.filter(member => {
        const matchesSearch = searchQuery === '' ||
          member.name.toLowerCase().includes(searchQuery.toLowerCase());
        
        return matchesSearch;
      });
      
      setTeamData(filtered);
      setIsLoading(false);
    }, 500);
    
    return () => clearTimeout(timer);
  }, [timeFilter, searchQuery]);

  // Prepare data for charts
  const memberNames = teamData.map(member => member.name);
  const ticketsResolvedData = teamData.map(member => member.ticketsResolved);
  const ritmsResolvedData = teamData.map(member => member.ritmsFulfilled);
  const slaComplianceData = teamData.map(member => member.slaCompliance);

  return (
    <div className="animate-fade-in">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">Team Performance</h1>
          <p className="text-neutral-600 mt-1">Monitor your team's efficiency metrics</p>
        </div>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto">
          <div className="relative w-full sm:w-64">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-neutral-400" />
            </div>
            <input
              type="text"
              placeholder="Search team members..."
              className="pl-10 pr-4 py-2 w-full border border-neutral-200 rounded-lg focus:ring-2 focus:ring-primary-200 focus:border-primary-500 outline-none"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <TimeFilter value={timeFilter} onChange={setTimeFilter} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        <SummaryCard title="Team Stats" className="col-span-full lg:col-span-1">
          <div className="space-y-4">
            <div className="p-4 bg-neutral-50 rounded-lg">
              <div className="flex items-center mb-2">
                <Check size={18} className="text-success-500 mr-2" />
                <h4 className="font-medium">Total Resolved</h4>
              </div>
              <p className="text-2xl font-semibold">
                {teamData.reduce((acc, curr) => acc + curr.ticketsResolved + curr.ritmsFulfilled, 0)}
              </p>
              <p className="text-sm text-neutral-500">combined tickets & RITMs</p>
            </div>
            
            <div className="p-4 bg-neutral-50 rounded-lg">
              <div className="flex items-center mb-2">
                <Clock size={18} className="text-primary-500 mr-2" />
                <h4 className="font-medium">Avg Resolution Time</h4>
              </div>
              <p className="text-2xl font-semibold">
                {(teamData.reduce((acc, curr) => acc + curr.avgResolutionTime, 0) / (teamData.length || 1)).toFixed(1)} days
              </p>
              <p className="text-sm text-neutral-500">across all team members</p>
            </div>
            
            <div className="p-4 bg-neutral-50 rounded-lg">
              <div className="flex items-center mb-2">
                <AlertCircle size={18} className="text-accent-500 mr-2" />
                <h4 className="font-medium">SLA/SLX Compliance</h4>
              </div>
              <p className="text-2xl font-semibold">
                {Math.round(teamData.reduce((acc, curr) => acc + curr.slaCompliance + curr.slxCompliance, 0) / (teamData.length * 2 || 1))}%
              </p>
              <p className="text-sm text-neutral-500">average compliance rate</p>
            </div>
          </div>
        </SummaryCard>

        <SummaryCard title="Team Resolution Metrics" className="col-span-full lg:col-span-2">
          <div className="h-[300px]">
            <BarChart
              labels={memberNames}
              datasets={[
                {
                  label: 'Tickets Resolved',
                  data: ticketsResolvedData,
                  backgroundColor: 'rgba(0, 102, 204, 0.7)',
                },
                {
                  label: 'RITMs Fulfilled',
                  data: ritmsResolvedData,
                  backgroundColor: 'rgba(255, 149, 0, 0.7)',
                }
              ]}
            />
          </div>
        </SummaryCard>
      </div>

      <SummaryCard title="Team Members" className="animate-slide-up">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            <div className="col-span-full flex justify-center py-8">
              <p className="text-neutral-500">Loading team data...</p>
            </div>
          ) : teamData.length === 0 ? (
            <div className="col-span-full flex justify-center py-8">
              <p className="text-neutral-500">No team members found.</p>
            </div>
          ) : (
            teamData.map((member) => {
              // Find the member details from teamMembers
              const memberDetails = teamMembers.find(m => m.id === member.memberId);
              
              return (
                <div key={member.memberId} className="bg-white border border-neutral-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                  <div className="p-6">
                    <div className="flex items-center mb-4">
                      {memberDetails?.avatar ? (
                        <img 
                          src={memberDetails.avatar} 
                          alt={member.name} 
                          className="w-12 h-12 rounded-full object-cover mr-4" 
                        />
                      ) : (
                        <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mr-4">
                          <User size={24} className="text-primary-600" />
                        </div>
                      )}
                      
                      <div>
                        <h3 className="font-semibold text-lg">{member.name}</h3>
                        <p className="text-neutral-500 text-sm">{memberDetails?.role || 'Support Specialist'}</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <div className="bg-neutral-50 p-3 rounded-lg">
                        <p className="text-sm text-neutral-600">Tickets</p>
                        <p className="font-semibold text-lg">{member.ticketsResolved}</p>
                      </div>
                      
                      <div className="bg-neutral-50 p-3 rounded-lg">
                        <p className="text-sm text-neutral-600">RITMs</p>
                        <p className="font-semibold text-lg">{member.ritmsFulfilled}</p>
                      </div>
                      
                      <div className="bg-neutral-50 p-3 rounded-lg">
                        <p className="text-sm text-neutral-600">SLA</p>
                        <p className="font-semibold text-lg">{member.slaCompliance}%</p>
                      </div>
                      
                      <div className="bg-neutral-50 p-3 rounded-lg">
                        <p className="text-sm text-neutral-600">Resolution</p>
                        <p className="font-semibold text-lg">{member.avgResolutionTime} days</p>
                      </div>
                    </div>

                    {(member.ticketsResolved + member.ritmsFulfilled > 25) && (
                      <div className="mt-4 flex justify-center">
                        <div className="inline-flex items-center px-3 py-1.5 bg-accent-100 text-accent-700 rounded-full text-sm">
                          <Award size={16} className="mr-1" /> Top Performer
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </SummaryCard>
    </div>
  );
};

export default TeamPage;
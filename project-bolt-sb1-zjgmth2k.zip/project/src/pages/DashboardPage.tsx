import React, { useState, useEffect } from 'react';
import { ArrowRight, RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';
import TimeFilter from '../components/ui/TimeFilter';
import TicketMetricsCard from '../components/dashboard/TicketMetricsCard';
import RITMMetricsCard from '../components/dashboard/RITMMetricsCard';
import TrendChart from '../components/dashboard/TrendChart';
import TeamPerformanceCard from '../components/dashboard/TeamPerformanceCard';
import CategoryDistributionCard from '../components/dashboard/CategoryDistributionCard';
import type { TimeFilter as TimeFilterType } from '../types';
import {
  fetchTicketMetrics,
  fetchRITMMetrics,
  fetchTeamPerformance,
  fetchDailyStats,
  fetchTicketCategoryDistribution,
  fetchRITMCategoryDistribution
} from '../constants/mockData';

const DashboardPage: React.FC = () => {
  const [timeFilter, setTimeFilter] = useState<TimeFilterType>('month');
  const [isLoading, setIsLoading] = useState(true);
  const [ticketMetrics, setTicketMetrics] = useState(null);
  const [ritmMetrics, setRITMMetrics] = useState(null);
  const [teamPerformance, setTeamPerformance] = useState([]);
  const [dailyStats, setDailyStats] = useState([]);
  const [ticketCategories, setTicketCategories] = useState([]);
  const [ritmCategories, setRITMCategories] = useState([]);

  const fetchDashboardData = async () => {
    setIsLoading(true);
    try {
      const [
        ticketMetricsData,
        ritmMetricsData,
        teamPerformanceData,
        dailyStatsData,
        ticketCategoriesData,
        ritmCategoriesData
      ] = await Promise.all([
        fetchTicketMetrics(timeFilter),
        fetchRITMMetrics(timeFilter),
        fetchTeamPerformance(timeFilter),
        fetchDailyStats(timeFilter),
        fetchTicketCategoryDistribution(timeFilter),
        fetchRITMCategoryDistribution(timeFilter)
      ]);

      setTicketMetrics(ticketMetricsData);
      setRITMMetrics(ritmMetricsData);
      setTeamPerformance(teamPerformanceData);
      setDailyStats(dailyStatsData);
      setTicketCategories(ticketCategoriesData);
      setRITMCategories(ritmCategoriesData);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [timeFilter]);

  const handleTimeFilterChange = (value: TimeFilterType) => {
    setTimeFilter(value);
  };

  const handleRefresh = () => {
    fetchDashboardData();
  };

  if (isLoading && !ticketMetrics) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center">
          <RefreshCw size={32} className="text-primary-500 animate-spin" />
          <p className="mt-2 text-neutral-600">Loading dashboard data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">Team Efficiency Dashboard</h1>
          <p className="text-neutral-600 mt-1">Track your team's performance metrics and trends</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleRefresh}
            className="p-2 rounded-lg text-neutral-600 hover:bg-neutral-100 transition-colors"
            aria-label="Refresh data"
          >
            <RefreshCw size={20} />
          </button>
          <TimeFilter value={timeFilter} onChange={handleTimeFilterChange} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {ticketMetrics && <TicketMetricsCard metrics={ticketMetrics} />}
        {ritmMetrics && <RITMMetricsCard metrics={ritmMetrics} />}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {dailyStats.length > 0 && <TrendChart data={dailyStats} />}
        {teamPerformance.length > 0 && (
          <div className="card animate-slide-up">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Top Performers</h3>
              <Link to="/team" className="text-primary-500 hover:text-primary-600 text-sm font-medium flex items-center">
                View All <ArrowRight size={16} className="ml-1" />
              </Link>
            </div>
            <div className="space-y-4">
              {teamPerformance.slice(0, 3).map((member) => (
                <div key={member.memberId} className="flex items-center justify-between p-3 bg-neutral-50 rounded-lg">
                  <div className="flex items-center">
                    <div className="h-9 w-9 bg-primary-100 rounded-full flex items-center justify-center mr-3">
                      <span className="text-primary-600 font-semibold text-sm">{member.name.charAt(0)}</span>
                    </div>
                    <div>
                      <p className="font-medium">{member.name}</p>
                      <p className="text-sm text-neutral-500">
                        {member.ticketsResolved} tickets · {member.ritmsFulfilled} RITMs
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <div className="px-2 py-1 bg-success-100 text-success-700 rounded-md text-xs font-medium">
                      {member.slaCompliance}% SLA
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {ticketCategories.length > 0 && (
          <CategoryDistributionCard 
            title="Ticket Categories" 
            data={ticketCategories}
            chartColors={['#0066CC', '#5856D6', '#AF52DE', '#FF2D55', '#FF9500']}
          />
        )}
        {ritmCategories.length > 0 && (
          <CategoryDistributionCard 
            title="RITM Categories" 
            data={ritmCategories}
            chartColors={['#FF9500', '#FFCC00', '#34C759', '#007AFF', '#5856D6']}
          />
        )}
      </div>

      <div className="mt-8">
        {teamPerformance.length > 0 && (
          <TeamPerformanceCard data={teamPerformance} />
        )}
      </div>
    </div>
  );
};

export default DashboardPage;
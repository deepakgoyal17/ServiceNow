import { addDays, format, subDays } from 'date-fns';
import type { 
  TeamMember, 
  Ticket, 
  RITM, 
  TicketMetrics, 
  RITMMetrics, 
  TeamMetrics,
  DailyStats,
  CategoryDistribution
} from '../types';

// Helper function to generate dates
const generateDate = (daysAgo: number) => format(subDays(new Date(), daysAgo), 'yyyy-MM-dd');
const generateFutureDate = (daysAhead: number) => format(addDays(new Date(), daysAhead), 'yyyy-MM-dd');

// Team Members
export const teamMembers: TeamMember[] = [
  {
    id: 'tm1',
    name: 'Alex Johnson',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100',
    role: 'Senior Support Specialist',
    department: 'IT Support'
  },
  {
    id: 'tm2',
    name: 'Samantha Lee',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100',
    role: 'Support Engineer',
    department: 'IT Support'
  },
  {
    id: 'tm3',
    name: 'Miguel Rodriguez',
    avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=100',
    role: 'Technical Support Specialist',
    department: 'IT Support'
  },
  {
    id: 'tm4',
    name: 'Emily Chen',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100',
    role: 'Support Analyst',
    department: 'IT Support'
  },
  {
    id: 'tm5',
    name: 'David Wilson',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=100',
    role: 'Junior Support Specialist',
    department: 'IT Support'
  }
];

// Tickets
export const tickets: Ticket[] = [
  {
    id: 't1',
    number: 'INC0001234',
    title: 'Unable to access email',
    priority: 'high',
    status: 'resolved',
    category: 'Email',
    assignedTo: 'tm1',
    createdAt: generateDate(10),
    resolvedAt: generateDate(9),
    sla: {
      target: generateDate(8),
      met: true
    }
  },
  {
    id: 't2',
    number: 'INC0001235',
    title: 'VPN connection issue',
    priority: 'medium',
    status: 'resolved',
    category: 'Network',
    assignedTo: 'tm2',
    createdAt: generateDate(9),
    resolvedAt: generateDate(7),
    sla: {
      target: generateDate(6),
      met: true
    }
  },
  {
    id: 't3',
    number: 'INC0001236',
    title: 'Printer not working',
    priority: 'low',
    status: 'resolved',
    category: 'Hardware',
    assignedTo: 'tm3',
    createdAt: generateDate(8),
    resolvedAt: generateDate(6),
    sla: {
      target: generateDate(5),
      met: true
    }
  },
  {
    id: 't4',
    number: 'INC0001237',
    title: 'Software installation failed',
    priority: 'medium',
    status: 'in progress',
    category: 'Software',
    assignedTo: 'tm4',
    createdAt: generateDate(7),
    resolvedAt: null,
    sla: {
      target: generateFutureDate(1),
      met: false
    }
  },
  {
    id: 't5',
    number: 'INC0001238',
    title: 'Password reset request',
    priority: 'low',
    status: 'resolved',
    category: 'Account',
    assignedTo: 'tm5',
    createdAt: generateDate(6),
    resolvedAt: generateDate(6),
    sla: {
      target: generateDate(5),
      met: true
    }
  },
  {
    id: 't6',
    number: 'INC0001239',
    title: 'Application crash',
    priority: 'critical',
    status: 'resolved',
    category: 'Software',
    assignedTo: 'tm1',
    createdAt: generateDate(5),
    resolvedAt: generateDate(4),
    sla: {
      target: generateDate(4),
      met: true
    }
  },
  {
    id: 't7',
    number: 'INC0001240',
    title: 'Network connectivity issues',
    priority: 'high',
    status: 'resolved',
    category: 'Network',
    assignedTo: 'tm2',
    createdAt: generateDate(4),
    resolvedAt: generateDate(3),
    sla: {
      target: generateDate(2),
      met: true
    }
  },
  {
    id: 't8',
    number: 'INC0001241',
    title: 'Monitor display issue',
    priority: 'low',
    status: 'resolved',
    category: 'Hardware',
    assignedTo: 'tm3',
    createdAt: generateDate(3),
    resolvedAt: generateDate(1),
    sla: {
      target: generateDate(0),
      met: true
    }
  },
  {
    id: 't9',
    number: 'INC0001242',
    title: 'File access permission error',
    priority: 'medium',
    status: 'resolved',
    category: 'Permissions',
    assignedTo: 'tm4',
    createdAt: generateDate(2),
    resolvedAt: generateDate(1),
    sla: {
      target: generateDate(0),
      met: true
    }
  },
  {
    id: 't10',
    number: 'INC0001243',
    title: 'Email delivery delayed',
    priority: 'medium',
    status: 'open',
    category: 'Email',
    assignedTo: 'tm5',
    createdAt: generateDate(1),
    resolvedAt: null,
    sla: {
      target: generateFutureDate(2),
      met: false
    }
  }
];

// RITMs
export const ritms: RITM[] = [
  {
    id: 'r1',
    number: 'RITM0005678',
    title: 'New laptop request',
    priority: 'medium',
    status: 'fulfilled',
    category: 'Hardware',
    assignedTo: 'tm1',
    createdAt: generateDate(15),
    fulfilledAt: generateDate(10),
    slx: {
      target: generateDate(8),
      met: true
    }
  },
  {
    id: 'r2',
    number: 'RITM0005679',
    title: 'Software license request',
    priority: 'low',
    status: 'fulfilled',
    category: 'Software',
    assignedTo: 'tm2',
    createdAt: generateDate(14),
    fulfilledAt: generateDate(11),
    slx: {
      target: generateDate(9),
      met: true
    }
  },
  {
    id: 'r3',
    number: 'RITM0005680',
    title: 'VPN access request',
    priority: 'high',
    status: 'fulfilled',
    category: 'Access',
    assignedTo: 'tm3',
    createdAt: generateDate(13),
    fulfilledAt: generateDate(12),
    slx: {
      target: generateDate(10),
      met: true
    }
  },
  {
    id: 'r4',
    number: 'RITM0005681',
    title: 'Mobile device enrollment',
    priority: 'medium',
    status: 'in progress',
    category: 'Mobile',
    assignedTo: 'tm4',
    createdAt: generateDate(12),
    fulfilledAt: null,
    slx: {
      target: generateFutureDate(1),
      met: false
    }
  },
  {
    id: 'r5',
    number: 'RITM0005682',
    title: 'Shared drive access',
    priority: 'low',
    status: 'fulfilled',
    category: 'Access',
    assignedTo: 'tm5',
    createdAt: generateDate(11),
    fulfilledAt: generateDate(9),
    slx: {
      target: generateDate(8),
      met: true
    }
  },
  {
    id: 'r6',
    number: 'RITM0005683',
    title: 'New email account',
    priority: 'medium',
    status: 'fulfilled',
    category: 'Email',
    assignedTo: 'tm1',
    createdAt: generateDate(10),
    fulfilledAt: generateDate(8),
    slx: {
      target: generateDate(7),
      met: true
    }
  },
  {
    id: 'r7',
    number: 'RITM0005684',
    title: 'Software installation',
    priority: 'low',
    status: 'fulfilled',
    category: 'Software',
    assignedTo: 'tm2',
    createdAt: generateDate(9),
    fulfilledAt: generateDate(7),
    slx: {
      target: generateDate(6),
      met: true
    }
  },
  {
    id: 'r8',
    number: 'RITM0005685',
    title: 'External website access',
    priority: 'high',
    status: 'fulfilled',
    category: 'Access',
    assignedTo: 'tm3',
    createdAt: generateDate(8),
    fulfilledAt: generateDate(5),
    slx: {
      target: generateDate(4),
      met: true
    }
  },
  {
    id: 'r9',
    number: 'RITM0005686',
    title: 'Monitor replacement',
    priority: 'low',
    status: 'in progress',
    category: 'Hardware',
    assignedTo: 'tm4',
    createdAt: generateDate(7),
    fulfilledAt: null,
    slx: {
      target: generateFutureDate(2),
      met: false
    }
  },
  {
    id: 'r10',
    number: 'RITM0005687',
    title: 'Cloud storage account',
    priority: 'medium',
    status: 'open',
    category: 'Cloud',
    assignedTo: 'tm5',
    createdAt: generateDate(6),
    fulfilledAt: null,
    slx: {
      target: generateFutureDate(3),
      met: false
    }
  }
];

// Metrics
export const ticketMetrics: TicketMetrics = {
  total: 10,
  resolved: 8,
  resolutionRate: 80,
  avgResolutionTime: 2.5,
  slaCompliance: 92
};

export const ritmMetrics: RITMMetrics = {
  total: 10,
  fulfilled: 7,
  fulfillmentRate: 70,
  avgFulfillmentTime: 4.2,
  slxCompliance: 88
};

export const teamPerformance: TeamMetrics[] = [
  {
    memberId: 'tm1',
    name: 'Alex Johnson',
    ticketsResolved: 18,
    ritmsFulfilled: 12,
    slaCompliance: 95,
    slxCompliance: 92,
    avgResolutionTime: 1.8
  },
  {
    memberId: 'tm2',
    name: 'Samantha Lee',
    ticketsResolved: 15,
    ritmsFulfilled: 10,
    slaCompliance: 92,
    slxCompliance: 88,
    avgResolutionTime: 2.1
  },
  {
    memberId: 'tm3',
    name: 'Miguel Rodriguez',
    ticketsResolved: 12,
    ritmsFulfilled: 8,
    slaCompliance: 90,
    slxCompliance: 85,
    avgResolutionTime: 2.3
  },
  {
    memberId: 'tm4',
    name: 'Emily Chen',
    ticketsResolved: 14,
    ritmsFulfilled: 9,
    slaCompliance: 88,
    slxCompliance: 90,
    avgResolutionTime: 2.4
  },
  {
    memberId: 'tm5',
    name: 'David Wilson',
    ticketsResolved: 10,
    ritmsFulfilled: 7,
    slaCompliance: 85,
    slxCompliance: 82,
    avgResolutionTime: 2.8
  }
];

export const dailyStats: DailyStats[] = [
  { date: generateDate(30), ticketsResolved: 3, ritmsFulfilled: 2 },
  { date: generateDate(29), ticketsResolved: 2, ritmsFulfilled: 1 },
  { date: generateDate(28), ticketsResolved: 4, ritmsFulfilled: 3 },
  { date: generateDate(27), ticketsResolved: 1, ritmsFulfilled: 2 },
  { date: generateDate(26), ticketsResolved: 3, ritmsFulfilled: 1 },
  { date: generateDate(25), ticketsResolved: 2, ritmsFulfilled: 2 },
  { date: generateDate(24), ticketsResolved: 5, ritmsFulfilled: 3 },
  { date: generateDate(23), ticketsResolved: 3, ritmsFulfilled: 2 },
  { date: generateDate(22), ticketsResolved: 4, ritmsFulfilled: 1 },
  { date: generateDate(21), ticketsResolved: 2, ritmsFulfilled: 2 },
  { date: generateDate(20), ticketsResolved: 3, ritmsFulfilled: 3 },
  { date: generateDate(19), ticketsResolved: 1, ritmsFulfilled: 1 },
  { date: generateDate(18), ticketsResolved: 4, ritmsFulfilled: 2 },
  { date: generateDate(17), ticketsResolved: 2, ritmsFulfilled: 2 },
  { date: generateDate(16), ticketsResolved: 3, ritmsFulfilled: 1 },
  { date: generateDate(15), ticketsResolved: 5, ritmsFulfilled: 3 },
  { date: generateDate(14), ticketsResolved: 2, ritmsFulfilled: 2 },
  { date: generateDate(13), ticketsResolved: 3, ritmsFulfilled: 1 },
  { date: generateDate(12), ticketsResolved: 4, ritmsFulfilled: 2 },
  { date: generateDate(11), ticketsResolved: 2, ritmsFulfilled: 3 },
  { date: generateDate(10), ticketsResolved: 3, ritmsFulfilled: 2 },
  { date: generateDate(9), ticketsResolved: 1, ritmsFulfilled: 1 },
  { date: generateDate(8), ticketsResolved: 4, ritmsFulfilled: 2 },
  { date: generateDate(7), ticketsResolved: 3, ritmsFulfilled: 3 },
  { date: generateDate(6), ticketsResolved: 2, ritmsFulfilled: 1 },
  { date: generateDate(5), ticketsResolved: 5, ritmsFulfilled: 2 },
  { date: generateDate(4), ticketsResolved: 3, ritmsFulfilled: 3 },
  { date: generateDate(3), ticketsResolved: 4, ritmsFulfilled: 2 },
  { date: generateDate(2), ticketsResolved: 2, ritmsFulfilled: 1 },
  { date: generateDate(1), ticketsResolved: 3, ritmsFulfilled: 2 },
  { date: generateDate(0), ticketsResolved: 4, ritmsFulfilled: 3 }
];

export const ticketCategoryDistribution: CategoryDistribution[] = [
  { category: 'Email', count: 12, percentage: 15 },
  { category: 'Network', count: 18, percentage: 22.5 },
  { category: 'Hardware', count: 10, percentage: 12.5 },
  { category: 'Software', count: 20, percentage: 25 },
  { category: 'Account', count: 8, percentage: 10 },
  { category: 'Permissions', count: 7, percentage: 8.75 },
  { category: 'Other', count: 5, percentage: 6.25 }
];

export const ritmCategoryDistribution: CategoryDistribution[] = [
  { category: 'Hardware', count: 14, percentage: 20 },
  { category: 'Software', count: 16, percentage: 22.85 },
  { category: 'Access', count: 12, percentage: 17.15 },
  { category: 'Mobile', count: 8, percentage: 11.43 },
  { category: 'Email', count: 7, percentage: 10 },
  { category: 'Cloud', count: 10, percentage: 14.28 },
  { category: 'Other', count: 3, percentage: 4.29 }
];

// Fetch data functions (mock implementations that would connect to ServiceNow API in a real app)
export const fetchTicketMetrics = (timeFilter: string): Promise<TicketMetrics> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // In a real implementation, this would filter based on the timeFilter
      resolve(ticketMetrics);
    }, 500);
  });
};

export const fetchRITMMetrics = (timeFilter: string): Promise<RITMMetrics> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // In a real implementation, this would filter based on the timeFilter
      resolve(ritmMetrics);
    }, 500);
  });
};

export const fetchTeamPerformance = (timeFilter: string): Promise<TeamMetrics[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // In a real implementation, this would filter based on the timeFilter
      resolve(teamPerformance);
    }, 500);
  });
};

export const fetchDailyStats = (timeFilter: string): Promise<DailyStats[]> => {
  return new Promise((resolve) => {
    let filteredStats: DailyStats[];
    
    // Filter based on timeFilter
    switch (timeFilter) {
      case 'week':
        filteredStats = dailyStats.slice(-7);
        break;
      case 'quarter':
        filteredStats = dailyStats;
        break;
      case 'month':
      default:
        filteredStats = dailyStats.slice(-30);
        break;
    }
    
    setTimeout(() => {
      resolve(filteredStats);
    }, 500);
  });
};

export const fetchTicketCategoryDistribution = (timeFilter: string): Promise<CategoryDistribution[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // In a real implementation, this would filter based on the timeFilter
      resolve(ticketCategoryDistribution);
    }, 500);
  });
};

export const fetchRITMCategoryDistribution = (timeFilter: string): Promise<CategoryDistribution[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // In a real implementation, this would filter based on the timeFilter
      resolve(ritmCategoryDistribution);
    }, 500);
  });
};